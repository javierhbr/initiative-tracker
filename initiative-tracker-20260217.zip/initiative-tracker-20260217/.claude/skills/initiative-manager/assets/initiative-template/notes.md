# Notes & Decisions

<!--
APPEND-ONLY LOG
Never edit entries above. Only add new entries below.
This maintains an immutable audit trail of decisions.
-->
