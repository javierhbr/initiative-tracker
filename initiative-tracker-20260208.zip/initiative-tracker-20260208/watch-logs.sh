#!/bin/bash
echo "Watching server logs (Ctrl+C to stop)..."
echo "========================================="
tail -f .server.log
